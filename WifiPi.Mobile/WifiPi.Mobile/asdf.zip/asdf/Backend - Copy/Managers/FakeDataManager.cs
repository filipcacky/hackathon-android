﻿namespace WifiPi.Mobile.Backend.Managers
{
	public class FakeDataManager
	{
		
	}
}