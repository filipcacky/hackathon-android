﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WifiPi.Mobile.Models
{
	public class EventItem
	{
		public string Date { get; set; }
		public int Users { get; set; }
	}
}
