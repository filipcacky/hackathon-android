﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WifiPi.Mobile.Models
{
	public class StatisticsItem
	{
		public string DateTime { get; set; }
		public int Count { get; set; }
	}
}
