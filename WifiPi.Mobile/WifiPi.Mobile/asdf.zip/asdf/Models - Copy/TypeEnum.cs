﻿namespace WifiPi.Mobile.Models
{
	public enum TypeEnum
	{
		pub = 0,
		restaurant = 1,
		coffee= 3,
		gym = 4,
		library = 5,
		other = 6
	}
}